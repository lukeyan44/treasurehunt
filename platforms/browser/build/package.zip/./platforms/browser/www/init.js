var ENV = {
	baseurl: 'https://www.grapevine.nu/mobile0/'
};

ENV.endpoint = ENV.baseurl+'api/';

var appPanes = {
	panes: {}
};